
    const DEFAULT_STORAGE = {
      landlords: [
        { email: "landlord@smartprop.com", pass: "admin123" }
      ],
      tenants: [
        { id: "T-101", name: "David Mugisha", unit: "Unit 101", pass: "Unit 101", contact: "+256 701 112233", lease: "2026-01-01 to 2026-12-31" },
        { id: "T-102", name: "Sarah K.", unit: "Unit 102", pass: "Unit 102", contact: "+256 772 334455", lease: "2026-02-01 to 2027-01-31" }
      ],
      payments: [
        { id: "P-101", tenantId: "T-101", unit: "Unit 101", totalDue: 600000, amountPaid: 600000, date: "2026-10-02", method: "MTN MoMo" },
        { id: "P-102", tenantId: "T-102", unit: "Unit 102", totalDue: 850000, amountPaid: 450000, date: "2026-10-06", method: "Airtel Money" }
      ],
      maintenance: [
        { id: "M-1", unit: "Unit 101", desc: "Bathroom sink faucet pipe leaking", date: "2026-10-10", status: "Resolved" },
        { id: "M-2", unit: "Unit 102", desc: "Main power outlet sparks when plugged", date: "2026-10-14", status: "Pending" }
      ]
    };

    let appData = JSON.parse(localStorage.getItem('smartprop_pms_db')) || DEFAULT_STORAGE;
    function syncData() {
      localStorage.setItem('smartprop_pms_db', JSON.stringify(appData));
      render();
    }

    // Default session is null so the centered form is shown first
    let activeSession = { role: null, user: null };
    let authRole = 'landlord';
    let authMode = 'login';

    function formatUGX(num) {
      return 'UGX ' + Number(num || 0).toLocaleString();
    }

    // DIRECT PDF DOWNLOAD ENGINE
    function downloadReceiptAsPDF() {
      const receiptElement = document.getElementById('printable-receipt-card');
      const downloadBtn = document.getElementById('btn-download-pdf-receipt');
      const tenantName = document.getElementById('r-name').textContent.trim() || 'Tenant';
      const unitNumber = document.getElementById('r-unit').textContent.trim() || 'Unit';

      downloadBtn.disabled = true;
      downloadBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Generating PDF...';

      const opt = {
        margin:       [10, 10, 10, 10],
        filename:     `Rent-Receipt-${unitNumber}-${tenantName.replace(/\s+/g, '_')}.pdf`,
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2, useCORS: true, letterRendering: true, backgroundColor: '#161d23' },
        jsPDF:        { unit: 'mm', format: 'a5', orientation: 'portrait' }
      };

      html2pdf().set(opt).from(receiptElement).save().then(() => {
        downloadBtn.disabled = false;
        downloadBtn.innerHTML = '<i class="fa-solid fa-file-arrow-down"></i> Download PDF Receipt';
        showCenterPopup('Download Complete', 'Your official rent receipt PDF was saved directly to your device.', 'success');
      }).catch(err => {
        downloadBtn.disabled = false;
        downloadBtn.innerHTML = '<i class="fa-solid fa-file-arrow-down"></i> Download PDF Receipt';
        showCenterPopup('Download Error', 'Could not generate PDF. Please try again.', 'error');
      });
    }

    function showCenterPopup(title, msg, type = 'success') {
      const modal = document.getElementById('modal-center-alert');
      const iconBox = document.getElementById('alert-icon-box');
      const icon = document.getElementById('alert-icon');
      
      document.getElementById('alert-title').textContent = title;
      document.getElementById('alert-msg').textContent = msg;

      iconBox.className = 'icon-circle ' + (type === 'success' ? 'success' : 'error');
      icon.className = type === 'success' ? 'fa-solid fa-check' : 'fa-solid fa-exclamation';

      modal.classList.add('active');
    }

    function closeCenterAlert() {
      document.getElementById('modal-center-alert').classList.remove('active');
    }

    function openCenterModal(id) { document.getElementById(id).classList.add('active'); }
    function closeCenterModal(id) { document.getElementById(id).classList.remove('active'); }

    // CENTERED FULL FORM LOGIC
    function selectRole(role) {
      authRole = role;
      document.getElementById('choice-landlord').classList.toggle('active', role === 'landlord');
      document.getElementById('choice-tenant').classList.toggle('active', role === 'tenant');
      updateAuthForms();
    }

    function setAuthMode(mode) {
      authMode = mode;
      document.getElementById('tab-login').classList.toggle('active', mode === 'login');
      document.getElementById('tab-signup').classList.toggle('active', mode === 'signup');
      updateAuthForms();
    }

    function updateAuthForms() {
      document.getElementById('form-landlord-login').style.display = (authRole === 'landlord' && authMode === 'login') ? 'block' : 'none';
      document.getElementById('form-landlord-signup').style.display = (authRole === 'landlord' && authMode === 'signup') ? 'block' : 'none';
      document.getElementById('form-tenant-login').style.display = (authRole === 'tenant' && authMode === 'login') ? 'block' : 'none';
      document.getElementById('form-tenant-signup').style.display = (authRole === 'tenant' && authMode === 'signup') ? 'block' : 'none';
    }

    function handleLandlordLogin(e) {
      e.preventDefault();
      const email = document.getElementById('ll-login-email').value.trim();
      const pass = document.getElementById('ll-login-pass').value.trim();

      const ll = appData.landlords.find(l => l.email.toLowerCase() === email.toLowerCase());
      if (ll && ll.pass === pass) {
        activeSession = { role: 'landlord', user: { email } };
        showCenterPopup('Welcome Landlord', 'Signed in as ' + email, 'success');
        applyView();
      } else {
        showCenterPopup('Authentication Failed', 'Invalid email or password. Default is admin123', 'error');
      }
    }

    function handleLandlordSignup(e) {
      e.preventDefault();
      const email = document.getElementById('ll-signup-email').value.trim();
      const pass = document.getElementById('ll-signup-pass').value.trim();

      if (appData.landlords.some(l => l.email.toLowerCase() === email.toLowerCase())) {
        showCenterPopup('Account Exists', 'This email is already registered. Please sign in.', 'error');
        return;
      }

      appData.landlords.push({ email, pass });
      syncData();
      activeSession = { role: 'landlord', user: { email } };
      showCenterPopup('Account Created', 'Landlord account registered successfully.', 'success');
      applyView();
    }

    function handleTenantLogin(e) {
      e.preventDefault();
      const unit = document.getElementById('tt-login-unit').value.trim();
      const pass = document.getElementById('tt-login-pass').value.trim();

      const tenant = appData.tenants.find(t => 
        t.unit.toLowerCase().replace(/\s/g,'') === unit.toLowerCase().replace(/\s/g,'')
      );

      if (tenant && tenant.pass === pass) {
        activeSession = { role: 'tenant', user: tenant };
        showCenterPopup('Welcome ' + tenant.name, 'Logged in to ' + tenant.unit, 'success');
        applyView();
      } else {
        showCenterPopup('Login Failed', 'Unit or password does not match.', 'error');
      }
    }

    function handleTenantSignup(e) {
      e.preventDefault();
      const name = document.getElementById('tt-reg-name').value.trim();
      const unit = document.getElementById('tt-reg-unit').value.trim();
      const pass = document.getElementById('tt-reg-pass').value.trim();

      let tenant = appData.tenants.find(t => 
        t.unit.toLowerCase().replace(/\s/g,'') === unit.toLowerCase().replace(/\s/g,'')
      );

      if (tenant) {
        showCenterPopup('Unit Occupied', 'A tenant is already registered for this unit.', 'error');
        return;
      }

      const newId = 'T-' + Math.floor(100 + Math.random() * 900);
      tenant = {
        id: newId,
        name: name,
        unit: unit,
        pass: pass,
        contact: "Registered via Web App",
        lease: "2026 Term"
      };
      appData.tenants.push(tenant);

      appData.payments.push({
        id: 'P-' + Date.now(),
        tenantId: newId,
        unit: unit,
        totalDue: 650000,
        amountPaid: 0,
        date: new Date().toISOString().split('T')[0],
        method: 'Pending'
      });
      syncData();

      activeSession = { role: 'tenant', user: tenant };
      showCenterPopup('Registration Complete', 'Registered successfully for ' + unit, 'success');
      applyView();
    }

    // LOG OUT: Takes the user back to the centered full form
    function logout() {
      activeSession = { role: null, user: null };
      applyView();
    }

    function applyView() {
      const authView = document.getElementById('auth-page-view');
      const dashboardWrapper = document.getElementById('dashboard-wrapper');
      const viewLL = document.getElementById('view-landlord');
      const viewTT = document.getElementById('view-tenant');
      const roleDisplay = document.getElementById('user-role-display');
      const logoutContainer = document.getElementById('nav-logout-container');

      if (!activeSession.user) {
        // Show Full Centered Blue-Red Form
        authView.style.display = 'flex';
        dashboardWrapper.style.display = 'none';
        roleDisplay.innerHTML = `<span class="role-badge"><i class="fa-solid fa-shield-halved"></i> Authentication Portal</span>`;
        logoutContainer.style.display = 'none';
        updateAuthForms();
      } else {
        // Hide Form, Show Respective Dashboard
        authView.style.display = 'none';
        dashboardWrapper.style.display = 'block';
        logoutContainer.style.display = 'block';

        if (activeSession.role === 'landlord') {
          viewLL.style.display = 'block';
          viewTT.style.display = 'none';
          roleDisplay.innerHTML = `<span class="role-badge"><i class="fa-solid fa-crown"></i> Landlord: ${activeSession.user.email}</span>`;
        } else {
          viewLL.style.display = 'none';
          viewTT.style.display = 'block';
          roleDisplay.innerHTML = `<span class="role-badge"><i class="fa-solid fa-house-user"></i> Tenant: ${activeSession.user.name} (${activeSession.user.unit})</span>`;
          document.getElementById('tenant-heading-name').textContent = `Welcome, ${activeSession.user.name}`;
          document.getElementById('t-my-unit').value = activeSession.user.unit;
        }
        render();
      }
    }

    function render() {
      renderMetrics();
      renderTenantsTable();
      renderPaymentsTable();
      renderMaintenanceTable();
      renderTenantPortal();
      populateSelectTenants();
    }

    function renderMetrics() {
      let totalRev = 0;
      let totalUnpaid = 0;

      appData.payments.forEach(p => {
        totalRev += parseFloat(p.amountPaid || 0);
        const rem = parseFloat(p.totalDue) - parseFloat(p.amountPaid);
        if (rem > 0) totalUnpaid += rem;
      });

      const activeRepairs = appData.maintenance.filter(m => m.status !== 'Resolved').length;

      document.getElementById('metric-tenants').textContent = appData.tenants.length;
      document.getElementById('metric-revenue').textContent = formatUGX(totalRev);
      document.getElementById('metric-unpaid').textContent = formatUGX(totalUnpaid);
      document.getElementById('metric-repairs').textContent = activeRepairs;
    }

    function renderTenantsTable() {
      const tbody = document.getElementById('tbody-tenants');
      tbody.innerHTML = '';
      appData.tenants.forEach(t => {
        tbody.innerHTML += `
          <tr>
            <td><strong>${t.id}</strong></td>
            <td>${t.name}</td>
            <td>${t.contact}</td>
            <td><span class="status-pill" style="background:#eef3f2; color:var(--dark-slate);">${t.unit}</span></td>
            <td>${t.lease}</td>
            <td>
              <button class="btn btn-outline" style="color:var(--danger); border-color:#fadbd8; padding:3px 8px;" onclick="removeTenant('${t.id}')">
                <i class="fa-solid fa-trash"></i>
              </button>
            </td>
          </tr>
        `;
      });
    }

    function renderPaymentsTable() {
      const tbody = document.getElementById('tbody-payments');
      tbody.innerHTML = '';
      appData.payments.forEach(p => {
        const bal = parseFloat(p.totalDue) - parseFloat(p.amountPaid);
        const isPaid = bal <= 0;
        tbody.innerHTML += `
          <tr>
            <td><strong>${p.tenantId}</strong></td>
            <td>${p.unit}</td>
            <td>${formatUGX(p.totalDue)}</td>
            <td style="color:var(--success); font-weight:700;">${formatUGX(p.amountPaid)}</td>
            <td style="color:${bal > 0 ? 'var(--danger)' : 'var(--text-muted)'}; font-weight:700;">${formatUGX(bal)}</td>
            <td>${p.date}</td>
            <td>${p.method}</td>
            <td>
              <span class="status-pill ${isPaid ? 'paid' : 'pending'}">
                ${isPaid ? 'Paid in Full' : 'Pending (' + formatUGX(bal) + ')'}
              </span>
            </td>
            <td>
              <div style="display:flex; gap:6px;">
                ${!isPaid ? `
                  <button class="btn btn-gold" style="padding:4px 8px; font-size:0.75rem;" onclick="quickMarkPaid('${p.tenantId}')" title="Mark Fully Paid">
                    <i class="fa-solid fa-check"></i> Mark Paid
                  </button>
                ` : ''}
                <button class="btn btn-outline" style="color:var(--slate-green); border-color:var(--border-color); padding:4px 8px; font-size:0.75rem;" onclick="openEditPaymentModal('${p.tenantId}')" title="Edit Amount">
                  <i class="fa-solid fa-pen"></i> Edit
                </button>
                <button class="btn btn-outline" style="color:var(--slate-green); border-color:var(--border-color); padding:4px 8px; font-size:0.75rem;" onclick="viewTenantFromLandlord('${p.tenantId}')" title="View Receipt">
                  <i class="fa-solid fa-eye"></i> View
                </button>
              </div>
            </td>
          </tr>
        `;
      });
    }

    function renderMaintenanceTable() {
      const tbody = document.getElementById('tbody-maintenance');
      tbody.innerHTML = '';
      appData.maintenance.forEach((m, idx) => {
        tbody.innerHTML += `
          <tr>
            <td><strong>${m.unit}</strong></td>
            <td>${m.desc}</td>
            <td>${m.date}</td>
            <td><span class="status-pill ${m.status === 'Resolved' ? 'resolved' : (m.status === 'Pending' ? 'pending' : 'reported')}">${m.status}</span></td>
            <td>
              <select onchange="updateMaintStatus(${idx}, this.value)" style="padding:4px; border-radius:6px; border:1px solid var(--border-color);">
                <option value="Issue Reported" ${m.status === 'Issue Reported' ? 'selected' : ''}>Reported</option>
                <option value="Pending" ${m.status === 'Pending' ? 'selected' : ''}>Pending</option>
                <option value="Resolved" ${m.status === 'Resolved' ? 'selected' : ''}>Resolved</option>
              </select>
            </td>
          </tr>
        `;
      });
    }

    function renderTenantPortal() {
      if (!activeSession.user || activeSession.role !== 'tenant') return;

      const tbodyTickets = document.getElementById('tbody-tenant-tickets');
      tbodyTickets.innerHTML = '';
      const tickets = appData.maintenance.filter(m => 
        m.unit.toLowerCase().replace(/\s/g,'') === activeSession.user.unit.toLowerCase().replace(/\s/g,'')
      );
      if (tickets.length === 0) {
        tbodyTickets.innerHTML = `<tr><td colspan="3" style="text-align:center; color:var(--text-muted);">No repair requests reported.</td></tr>`;
      } else {
        tickets.forEach(t => {
          tbodyTickets.innerHTML += `
            <tr>
              <td>${t.desc}</td>
              <td>${t.date}</td>
              <td><span class="status-pill ${t.status === 'Resolved' ? 'resolved' : 'pending'}">${t.status}</span></td>
            </tr>
          `;
        });
      }

      const payment = appData.payments.find(p => 
        (p.tenantId && activeSession.user.id && p.tenantId.toLowerCase() === activeSession.user.id.toLowerCase()) ||
        (p.unit && activeSession.user.unit && p.unit.toLowerCase().replace(/\s/g,'') === activeSession.user.unit.toLowerCase().replace(/\s/g,''))
      );

      const paidContainer = document.getElementById('tenant-paid-container');
      const pendingContainer = document.getElementById('tenant-pending-container');
      const badgeStatus = document.getElementById('tenant-badge-status');

      if (payment) {
        const bal = parseFloat(payment.totalDue) - parseFloat(payment.amountPaid);
        const isPaidInFull = (bal <= 0) && (parseFloat(payment.totalDue) > 0);

        if (isPaidInFull) {
          pendingContainer.style.display = 'none';
          paidContainer.style.display = 'flex';
          badgeStatus.innerHTML = `<span class="status-pill paid"><i class="fa-solid fa-check"></i> Cleared & Settled</span>`;

          document.getElementById('r-ref').textContent = 'RCP-' + payment.id.replace('P-', '');
          document.getElementById('r-name').textContent = activeSession.user.name;
          document.getElementById('r-unit').textContent = payment.unit;
          document.getElementById('r-date').textContent = payment.date;
          document.getElementById('r-method').textContent = payment.method;
          document.getElementById('r-due').textContent = formatUGX(payment.totalDue);
          document.getElementById('r-paid').textContent = formatUGX(payment.amountPaid);
          document.getElementById('r-balance').textContent = 'UGX 0';
        } else {
          paidContainer.style.display = 'none';
          pendingContainer.style.display = 'block';
          badgeStatus.innerHTML = `<span class="status-pill pending"><i class="fa-solid fa-clock"></i> Payment Pending</span>`;
          document.getElementById('pending-amt-label').textContent = formatUGX(Math.max(0, bal)) + ' Due';
        }
      } else {
        paidContainer.style.display = 'none';
        pendingContainer.style.display = 'block';
        badgeStatus.innerHTML = `<span class="status-pill pending"><i class="fa-solid fa-clock"></i> Payment Pending</span>`;
        document.getElementById('pending-amt-label').textContent = 'UGX 0';
      }
    }

    function populateSelectTenants() {
      const sel = document.getElementById('in-pay-tenant');
      if (!sel) return;
      sel.innerHTML = '<option value="">-- Choose Tenant --</option>';
      appData.tenants.forEach(t => {
        sel.innerHTML += `<option value="${t.id}">${t.id} - ${t.name} (${t.unit})</option>`;
      });
    }

    function autoFillPaymentFields(tId) {
      const payment = appData.payments.find(p => p.tenantId === tId);
      if (payment) {
        document.getElementById('in-pay-due').value = payment.totalDue;
        document.getElementById('in-pay-amount').value = payment.amountPaid;
        document.getElementById('in-pay-method').value = payment.method;
      }
    }

    function switchTab(name, btn) {
      document.querySelectorAll('.tab-link').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      document.getElementById('tab-tenants-content').style.display = name === 'tenants' ? 'block' : 'none';
      document.getElementById('tab-payments-content').style.display = name === 'payments' ? 'block' : 'none';
      document.getElementById('tab-maintenance-content').style.display = name === 'maintenance' ? 'block' : 'none';
    }

    function saveNewTenant(e) {
      e.preventDefault();
      const tId = document.getElementById('in-tenant-id').value.trim();
      const unit = document.getElementById('in-tenant-unit').value.trim();
      const rent = parseFloat(document.getElementById('in-tenant-rent').value) || 600000;

      appData.tenants.push({
        id: tId,
        name: document.getElementById('in-tenant-name').value.trim(),
        contact: document.getElementById('in-tenant-contact').value.trim(),
        unit: unit,
        lease: document.getElementById('in-tenant-lease').value.trim()
      });

      appData.payments.push({
        id: 'P-' + Math.floor(100 + Math.random() * 900),
        tenantId: tId,
        unit: unit,
        totalDue: rent,
        amountPaid: 0,
        date: new Date().toISOString().split('T')[0],
        method: 'Pending'
      });

      closeCenterModal('modal-add-tenant');
      e.target.reset();
      syncData();
      showCenterPopup('Tenant Created', 'New tenant registered with rent: ' + formatUGX(rent), 'success');
    }

    function removeTenant(id) {
      appData.tenants = appData.tenants.filter(t => t.id !== id);
      appData.payments = appData.payments.filter(p => p.tenantId !== id);
      syncData();
      showCenterPopup('Deleted', 'Tenant record removed.', 'info');
    }

    function saveNewPayment(e) {
      e.preventDefault();
      const tId = document.getElementById('in-pay-tenant').value;
      const tenant = appData.tenants.find(t => t.id === tId);

      const totalDue = parseFloat(document.getElementById('in-pay-due').value);
      const amountPaid = parseFloat(document.getElementById('in-pay-amount').value);
      const date = new Date().toISOString().split('T')[0];
      const method = document.getElementById('in-pay-method').value;

      let existingPayment = appData.payments.find(p => p.tenantId === tId);

      if (existingPayment) {
        existingPayment.totalDue = totalDue;
        existingPayment.amountPaid = amountPaid;
        existingPayment.date = date;
        existingPayment.method = method;
      } else {
        appData.payments.push({
          id: 'P-' + Math.floor(100 + Math.random() * 900),
          tenantId: tId,
          unit: tenant ? tenant.unit : 'Unit --',
          totalDue: totalDue,
          amountPaid: amountPaid,
          date: date,
          method: method
        });
      }

      closeCenterModal('modal-add-payment');
      e.target.reset();
      syncData();
      showCenterPopup('Payment Updated', 'Payment logged: ' + formatUGX(amountPaid), 'success');
    }

    function quickMarkPaid(tId) {
      const payment = appData.payments.find(p => p.tenantId === tId);
      if (payment) {
        payment.amountPaid = payment.totalDue;
        payment.date = new Date().toISOString().split('T')[0];
        syncData();
        showCenterPopup('Marked Paid!', 'Tenant ' + tId + ' is now fully paid in UGX. Receipt is unlocked.', 'success');
      }
    }

    function openEditPaymentModal(tId) {
      document.getElementById('in-pay-tenant').value = tId;
      autoFillPaymentFields(tId);
      openCenterModal('modal-add-payment');
    }

    function saveNewMaintenance(e) {
      e.preventDefault();
      appData.maintenance.unshift({
        id: 'M-' + Date.now(),
        unit: document.getElementById('in-maint-unit').value.trim(),
        desc: document.getElementById('in-maint-desc').value.trim(),
        date: new Date().toISOString().split('T')[0],
        status: document.getElementById('in-maint-status').value
      });
      closeCenterModal('modal-add-maintenance');
      e.target.reset();
      syncData();
      showCenterPopup('Repair Logged', 'Maintenance ticket created.', 'success');
    }

    function updateMaintStatus(idx, status) {
      appData.maintenance[idx].status = status;
      syncData();
      showCenterPopup('Status Updated', 'Ticket status changed to ' + status, 'success');
    }

    function handleTenantSubmitTicket(e) {
      e.preventDefault();
      appData.maintenance.unshift({
        id: 'M-' + Date.now(),
        unit: activeSession.user.unit,
        desc: document.getElementById('t-my-desc').value.trim(),
        date: new Date().toISOString().split('T')[0],
        status: 'Issue Reported'
      });
      document.getElementById('t-my-desc').value = '';
      syncData();
      showCenterPopup('Ticket Submitted', 'Your maintenance request has been forwarded to property management.', 'success');
    }

    function viewTenantFromLandlord(tenantId) {
      const tenant = appData.tenants.find(t => t.id === tenantId);
      if (tenant) {
        activeSession = { role: 'tenant', user: tenant };
        applyView();
      }
    }

    // Initialize with the full centered Blue & Red form visible
    applyView();
  
